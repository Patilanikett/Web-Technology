
let editingRow = null;

function addStudent() {

    let id = document.getElementById("sid").value.trim();
    let name = document.getElementById("name").value.trim();
    let marks = document.getElementById("marks").value;

    if (id === "" || name === "" || marks === "") {
        alert("Please fill all fields");
        return;
    }

    if (Number(marks) < 0 || Number(marks) > 100) {
        alert("Marks must be between 0 and 100");
        return;
    }

    let tbody = document.getElementById("studentData");

    if (editingRow !== null) {

        editingRow.cells[0].innerText = id;
        editingRow.cells[1].innerText = name;
        editingRow.cells[2].innerText = marks;

        editingRow = null;

    } else {

        let row = tbody.insertRow();

        row.insertCell(0).innerText = id;
        row.insertCell(1).innerText = name;
        row.insertCell(2).innerText = marks;

        let action = row.insertCell(3);

        let editBtn = document.createElement("button");
        editBtn.innerText = "Edit";

        editBtn.onclick = function() {

            editingRow = row;

            document.getElementById("sid").value = row.cells[0].innerText;
            document.getElementById("name").value = row.cells[1].innerText;
            document.getElementById("marks").value = row.cells[2].innerText;
        };

        let deleteBtn = document.createElement("button");
        deleteBtn.innerText = "Delete";

        deleteBtn.onclick = function() {
            if (editingRow === row) {
                editingRow = null;
            }
            row.remove();
        };

        action.appendChild(editBtn);
        action.appendChild(deleteBtn);
    }

    document.getElementById("sid").value = "";
    document.getElementById("name").value = "";
    document.getElementById("marks").value = "";
}
