
function calculate(operator) {

    let a = Number(document.getElementById("num1").value);
    let b = Number(document.getElementById("num2").value);

    let result;

    if (document.getElementById("num1").value === "" ||
        document.getElementById("num2").value === "") {
        result = "Enter both numbers";
    }

    else if (operator === "+") {
        result = a + b;
    }

    else if (operator === "-") {
        result = a - b;
    }

    else if (operator === "*") {
        result = a * b;
    }

    else if (operator === "/") {
        result = b === 0 ? "Cannot divide by zero" : a / b;
    }

    document.getElementById("result").innerText = "Result: " + result;
}
