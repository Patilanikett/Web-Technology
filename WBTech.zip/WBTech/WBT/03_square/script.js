
function getNumbers() {
    let a = document.getElementById("num1").value;
    let b = document.getElementById("num2").value;

    if (a.trim() === "" || b.trim() === "" || isNaN(a) || isNaN(b)) {
        document.getElementById("result").innerHTML = "Enter valid numbers";
        return null;
    }

    return {
        n1: Number(a),
        n2: Number(b)
    };
}

function add() {
    let n = getNumbers();
    if (n === null) return;

    document.getElementById("result").innerHTML =
        "Addition = " + (n.n1 + n.n2);
}

function sub() {
    let n = getNumbers();
    if (n === null) return;

    document.getElementById("result").innerHTML =
        "Subtraction = " + (n.n1 - n.n2);
}

function mul() {
    let n = getNumbers();
    if (n === null) return;

    document.getElementById("result").innerHTML =
        "Multiplication = " + (n.n1 * n.n2);
}

function div() {
    let n = getNumbers();
    if (n === null) return;

    if (n.n2 === 0) {
        document.getElementById("result").innerHTML =
            "Cannot divide by zero";
        return;
    }

    document.getElementById("result").innerHTML =
        "Division = " + (n.n1 / n.n2);
}

function square() {
    let n = document.getElementById("num1").value;

    if (n.trim() === "" || isNaN(n)) {
        document.getElementById("result").innerHTML =
            "Enter first number";
        return;
    }

    n = Number(n);

    document.getElementById("result").innerHTML =
        "Square = " + (n * n);
}

function cube() {
    let n = document.getElementById("num1").value;

    if (n.trim() === "" || isNaN(n)) {
        document.getElementById("result").innerHTML =
            "Enter first number";
        return;
    }

    n = Number(n);

    document.getElementById("result").innerHTML =
        "Cube = " + (n * n * n);
}

function evenOdd() {
    let n = document.getElementById("num1").value;

    if (n.trim() === "" || !Number.isInteger(Number(n))) {
        document.getElementById("result").innerHTML =
            "Enter a valid whole number";
        return;
    }

    n = Number(n);

    if (n % 2 === 0) {
        document.getElementById("result").innerHTML = n + " is Even";
    } else {
        document.getElementById("result").innerHTML = n + " is Odd";
    }
}
