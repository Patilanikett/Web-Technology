const employees = [
    { id: 1, name: "Aniket", role: "Developer", salary: 30000 },
    { id: 2, name: "Rahul", role: "Tester", salary: 25000 },
    { id: 3, name: "Priya", role: "Designer", salary: 28000 },
    { id: 4, name: "Amit", role: "Manager", salary: 45000 }
];

const tableBody = document.getElementById("employeeData");

employees.forEach(employee => {
    const row = document.createElement("tr");
    row.innerHTML = `
        <td>${employee.id}</td>
        <td>${employee.name}</td>
        <td>${employee.role}</td>
        <td>₹${employee.salary}</td>
    `;
    tableBody.appendChild(row);
});
