// Get input value
function getNumber() {

    let num = document.getElementById("number").value;

    if (num.trim() === "") {
        document.getElementById("result").innerText =
            "Please enter a number";

        return null;
    }

    return Number(num);
}


// Cube of number
function cube() {

    let num = getNumber();

    if (num === null) return;

    let result = num * num * num;

    document.getElementById("result").innerText =
        "Cube = " + result;

}


// Square of number
function square() {

    let num = getNumber();

    if (num === null) return;

    let result = num * num;

    document.getElementById("result").innerText =
        "Square = " + result;

}


// Check even number
function even() {

    let num = getNumber();

    if (num === null) return;

    if (Number.isInteger(num) && num % 2 === 0) {

        document.getElementById("result").innerText =
            num + " is an Even Number";

    } else {

        document.getElementById("result").innerText =
            "Not an Even Integer";

    }

}


// Check odd number
function odd() {

    let num = getNumber();

    if (num === null) return;

    if (Number.isInteger(num) && num % 2 !== 0) {

        document.getElementById("result").innerText =
            num + " is an Odd Number";

    } else {

        document.getElementById("result").innerText =
            "Not an Odd Integer";

    }

}