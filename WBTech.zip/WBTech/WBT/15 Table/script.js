// Add Student
function addStudent() {

    let id = document.getElementById("studentId").value;

    let roll = document.getElementById("rollNo").value;

    let name = document.getElementById("name").value;

    let marks = document.getElementById("marks").value;

    let department = document.getElementById("department").value;

    // Validation
    if (
        id.trim() === "" ||
        roll.trim() === "" ||
        name.trim() === "" ||
        marks.trim() === "" ||
        department.trim() === ""
    ) {
        alert("Please enter all student details");
        return;
    }

    if (Number(marks) < 0 || Number(marks) > 100) {
        alert("Marks must be between 0 and 100");
        return;
    }

    // Create new row
    let table = document.getElementById("tableBody");

    let row = table.insertRow();

    // Insert cells
    row.insertCell(0).innerText = id;

    row.insertCell(1).innerText = roll;

    row.insertCell(2).innerText = name;

    row.insertCell(3).innerText = marks;

    row.insertCell(4).innerText = department;

    // Clear input fields
    document.getElementById("studentId").value = "";
    document.getElementById("rollNo").value = "";
    document.getElementById("name").value = "";
    document.getElementById("marks").value = "";
    document.getElementById("department").value = "";

    document.getElementById("message").innerText =
        "Student added successfully!";

}


// Change Table Cell Color
function changeColor() {

    let rowNo = Number(document.getElementById("rowNo").value);

    let colNo = Number(document.getElementById("colNo").value);

    let color = document.getElementById("color").value;

    let table = document.getElementById("studentTable");

    // Validate row and column
    if (
        !Number.isInteger(rowNo) ||
        !Number.isInteger(colNo) ||
        rowNo < 1 ||
        rowNo > table.rows.length ||
        colNo < 1 ||
        colNo > 5
    ) {
        alert("Enter a valid row and column number");
        return;
    }

    // Select cell
    let cell = table.rows[rowNo - 1].cells[colNo - 1];

    // Apply color
    cell.style.backgroundColor = color;

    document.getElementById("message").innerText =
        "Cell color changed successfully!";

}


// Reset Table Cell Colors
function resetColor() {

    let table = document.getElementById("studentTable");

    for (let i = 0; i < table.rows.length; i++) {

        for (let j = 0; j < table.rows[i].cells.length; j++) {

            let cell = table.rows[i].cells[j];

            if (i === 0) {
                cell.style.backgroundColor = "navy";
                cell.style.color = "white";
            } else {
                cell.style.backgroundColor = "white";
                cell.style.color = "black";
            }

        }

    }

    document.getElementById("message").innerText =
        "All cell colors reset successfully!";

}