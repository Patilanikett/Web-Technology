document.getElementById("myForm").addEventListener("submit", function(e) {

    e.preventDefault();

    let name = document.getElementById("name").value.trim();
    let email = document.getElementById("email").value.trim();
    let mobile = document.getElementById("mobile").value.trim();
    let password = document.getElementById("password").value;
    let confirm = document.getElementById("confirm").value;

    let valid = true;

    document.querySelectorAll("span").forEach(s => s.innerText = "");
    document.getElementById("result").innerText = "";

    if (name === "") {
        nameError.innerText = "Name required";
        valid = false;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        emailError.innerText = "Invalid email";
        valid = false;
    }

    if (!/^[6-9][0-9]{9}$/.test(mobile)) {
        mobileError.innerText = "Invalid mobile";
        valid = false;
    }

    if (password.length < 8) {
        passError.innerText = "Minimum 8 characters required";
        valid = false;
    }

    if (password !== confirm || confirm === "") {
        confirmError.innerText = "Password does not match";
        valid = false;
    }

    if (valid) {
        document.getElementById("result").innerText =
            "Registration Successful!";
        document.getElementById("result").style.color = "green";

        this.reset();
    }

});
