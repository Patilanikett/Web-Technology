
function changeColor(color) {

    document.body.style.backgroundColor = color;

    document.getElementById("colorName").innerText =
        "Current Color: " + color;
}

function randomColor() {

    let random = Math.floor(Math.random() * 16777215);

    let color = "#" + random.toString(16).padStart(6, "0");

    document.body.style.backgroundColor = color;

    document.getElementById("colorName").innerText =
        "Current Color: " + color;
}

function resetColor() {

    document.body.style.backgroundColor = "white";

    document.getElementById("colorName").innerText =
        "Current Color: White";
}
