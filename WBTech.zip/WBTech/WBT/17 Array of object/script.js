// Array of objects

let students = [

    {
        id: 101,
        rollNo: 1,
        name: "Rohit",
        marks: 85,
        department: "Computer"
    },

    {
        id: 102,
        rollNo: 2,
        name: "Amit",
        marks: 90,
        department: "IT"
    },

    {
        id: 103,
        rollNo: 3,
        name: "Rahul",
        marks: 78,
        department: "ENTC"
    },

    {
        id: 104,
        rollNo: 4,
        name: "Akash",
        marks: 88,
        department: "Mechanical"
    },

    {
        id: 105,
        rollNo: 5,
        name: "Pratik",
        marks: 92,
        department: "Computer"
    }

];


// Get table body
let tableBody = document.getElementById("tableBody");


// Display array data into table

students.forEach(function(student) {

    let row = document.createElement("tr");

    row.innerHTML = `
        <td>${student.id}</td>
        <td>${student.rollNo}</td>
        <td>${student.name}</td>
        <td>${student.marks}</td>
        <td>${student.department}</td>
    `;

    tableBody.appendChild(row);

});