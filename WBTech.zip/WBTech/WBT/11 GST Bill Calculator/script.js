
function calculateBill() {

    // Get input values

    let product = document.getElementById("product").value.trim();

    let price = document.getElementById("price").value;

    let quantity = document.getElementById("quantity").value;

    let gst = Number(document.getElementById("gst").value);


    // Validation

    if (product === "" || price === "" || quantity === "") {

        alert("Please fill all fields");

        return;
    }

    price = Number(price);
    quantity = Number(quantity);

    if (!Number.isFinite(price) || !Number.isFinite(quantity) ||
        price <= 0 || quantity <= 0) {

        alert("Price and quantity must be greater than zero");

        return;
    }


    // Calculate subtotal

    let subtotal = price * quantity;


    // Calculate CGST and SGST

    let cgst = subtotal * gst / 200;

    let sgst = subtotal * gst / 200;


    // Calculate total GST

    let totalGST = cgst + sgst;


    // Calculate final bill

    let finalAmount = subtotal + totalGST;


    // Display bill details

    document.getElementById("pname").innerText = product;

    document.getElementById("subtotal").innerText =
        subtotal.toFixed(2);

    document.getElementById("cgst").innerText =
        cgst.toFixed(2);

    document.getElementById("sgst").innerText =
        sgst.toFixed(2);

    document.getElementById("totalgst").innerText =
        totalGST.toFixed(2);

    document.getElementById("final").innerText =
        finalAmount.toFixed(2);

}
