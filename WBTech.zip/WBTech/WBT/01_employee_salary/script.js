function calculateSalary() {
    const name = document.getElementById("name").value.trim();
    const basic = Number(document.getElementById("basic").value);
    const hra = Number(document.getElementById("hra").value);
    const allowance = Number(document.getElementById("allowance").value);
    const deduction = Number(document.getElementById("deduction").value);

    if (!name || [basic, hra, allowance, deduction].some(value => value < 0) ||
        [basic, hra, allowance, deduction].some(value => !Number.isFinite(value))) {
        document.getElementById("result").textContent = "Enter a name and valid non-negative amounts.";
        return;
    }

    const gross = basic + hra + allowance;
    const net = gross - deduction;

    document.getElementById("result").innerHTML =
        `<strong>Employee:</strong> ${name}<br>
         <strong>Gross Salary:</strong> ₹${gross.toFixed(2)}<br>
         <strong>Net Salary:</strong> ₹${net.toFixed(2)}`;
}
