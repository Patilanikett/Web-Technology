let text = document.getElementById("text");

let findWord = document.getElementById("findWord");

let replaceWord = document.getElementById("replaceWord");

let output = document.getElementById("output");


// Replace only first occurrence
function replaceOne() {

    let originalText = text.value;

    let find = findWord.value;

    let replace = replaceWord.value;

    if (find === "") {
        alert("Please enter word to find");
        return;
    }

    let result = originalText.replace(find, replace);

    text.value = result;

    output.innerText = result;

}


// Replace all occurrences
function replaceAll() {

    let originalText = text.value;

    let find = findWord.value;

    let replace = replaceWord.value;

    if (find === "") {
        alert("Please enter word to find");
        return;
    }

    let result = originalText.replaceAll(find, replace);

    text.value = result;

    output.innerText = result;

}


// Clear all text
function clearText() {

    text.value = "";

    findWord.value = "";

    replaceWord.value = "";

    output.innerText = "";

}