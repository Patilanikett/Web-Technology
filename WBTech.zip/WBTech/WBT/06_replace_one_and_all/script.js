function getReplacementValues() {
    return {
        original: document.getElementById("original").value,
        search: document.getElementById("searchText").value,
        replacement: document.getElementById("replaceText").value
    };
}

function replaceOne() {
    const values = getReplacementValues();

    if (values.search === "") {
        alert("Enter text to find.");
        return;
    }

    document.getElementById("output").value =
        values.original.replace(values.search, values.replacement);
}

function replaceAllText() {
    const values = getReplacementValues();

    if (values.search === "") {
        alert("Enter text to find.");
        return;
    }

    document.getElementById("output").value =
        values.original.replaceAll(values.search, values.replacement);
}
