function checkNumber() {
    const input = document.getElementById("number").value;
    const result = document.getElementById("result");

    if (input.trim() === "") {
        result.textContent = "Please enter a number.";
        return;
    }

    const number = Number(input);
    if (!Number.isInteger(number)) {
        result.textContent = "Please enter a whole number (integer).";
        return;
    }

    const absolute = Math.abs(number);
    const squareRoot = Math.sqrt(absolute);
    const cubeRoot = Math.cbrt(number);
    const isSquare = Number.isInteger(squareRoot);
    const isCube = Number.isInteger(cubeRoot);

    result.innerHTML =
        `<strong>${number}</strong> is ${number % 2 === 0 ? "Even" : "Odd"}.<br>
         Perfect square: ${isSquare ? "Yes" : "No"}<br>
         Perfect cube: ${isCube ? "Yes" : "No"}`;
}
