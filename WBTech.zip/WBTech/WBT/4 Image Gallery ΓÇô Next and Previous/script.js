
let images = [
    {src: "https://picsum.photos/id/1015/600/350", name: "Mountain"},
    {src: "https://picsum.photos/id/1018/600/350", name: "Forest"},
    {src: "https://picsum.photos/id/1019/600/350", name: "Nature"},
    {src: "https://picsum.photos/id/1020/600/350", name: "Landscape"}
];

let index = 0;

function displayImage() {
    document.getElementById("myImage").src = images[index].src;
    document.getElementById("imageName").innerText = images[index].name;
}

function nextImage() {
    index++;

    if (index >= images.length) {
        index = 0;
    }

    displayImage();
}

function previousImage() {
    index--;

    if (index < 0) {
        index = images.length - 1;
    }

    displayImage();
}

function toggleImage() {
    let img = document.getElementById("myImage");

    if (img.style.display === "none") {
        img.style.display = "block";
    } else {
        img.style.display = "none";
    }
}
