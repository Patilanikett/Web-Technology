let text1 = document.getElementById("text1");
let text2 = document.getElementById("text2");

let button = document.getElementById("transferBtn");

button.addEventListener("click", function() {

    let value = text1.value;

    text2.value = value;

});