
function calculate() {

    let m1 = Number(document.getElementById("m1").value);
    let m2 = Number(document.getElementById("m2").value);
    let m3 = Number(document.getElementById("m3").value);
    let m4 = Number(document.getElementById("m4").value);
    let m5 = Number(document.getElementById("m5").value);

    let fields = ["m1", "m2", "m3", "m4", "m5"];

    for (let id of fields) {
        let value = document.getElementById(id).value;

        if (value === "" || Number(value) < 0 || Number(value) > 100) {
            document.getElementById("result").innerText =
                "Enter valid marks between 0 and 100";
            return;
        }
    }

    let total = m1 + m2 + m3 + m4 + m5;

    let percentage = total / 5;

    let grade;

    if ([m1, m2, m3, m4, m5].some(m => m < 35)) {
        grade = "Fail";
    }
    else if (percentage >= 90) {
        grade = "A+";
    }
    else if (percentage >= 80) {
        grade = "A";
    }
    else if (percentage >= 70) {
        grade = "B";
    }
    else if (percentage >= 60) {
        grade = "C";
    }
    else {
        grade = "D";
    }

    document.getElementById("result").innerHTML =
        "Total: " + total + "/500<br>" +
        "Percentage: " + percentage + "%<br>" +
        "Grade: " + grade;
}
