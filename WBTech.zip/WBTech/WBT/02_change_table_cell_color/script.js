function changeCellColor() {
    const cellNumber = document.getElementById("cellNumber").value.trim();
    const color = document.getElementById("colorPicker").value;
    const message = document.getElementById("message");

    if (cellNumber === "" || !Number.isInteger(Number(cellNumber)) ||
        Number(cellNumber) < 1 || Number(cellNumber) > 9) {
        message.textContent = "Please enter a cell number from 1 to 9.";
        return;
    }

    const cells = document.querySelectorAll("td");
    cells[Number(cellNumber) - 1].style.backgroundColor = color;
    message.textContent = "Cell " + cellNumber + " background color changed.";
}
