
function togglePassword() {

    let pass = document.getElementById("password");

    if (pass.type === "password") {
        pass.type = "text";
    } else {
        pass.type = "password";
    }
}

function login() {

    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

    let message = document.getElementById("message");

    if (email === "admin@gmail.com" && password === "12345") {
        message.innerText = "Login Successful!";
        message.style.color = "green";
    }

    else {
        message.innerText = "Invalid Email or Password";
        message.style.color = "red";
    }
}
