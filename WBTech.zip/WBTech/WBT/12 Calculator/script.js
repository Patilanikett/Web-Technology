let display = document.getElementById("display");

// Display the clicked value
function appendValue(value) {
    display.value = display.value + value;
}

// Clear the complete display
function clearDisplay() {
    display.value = "";
}

// Delete the last character
function deleteLast() {
    display.value = display.value.slice(0, -1);
}

// Calculate the result
function calculate() {
    try {

        if (display.value === "") {
            alert("Please enter a calculation");
            return;
        }

        let result = eval(display.value);

        if (!Number.isFinite(result)) {
            throw new Error("Invalid calculation");
        }

        display.value = result;

    } catch (error) {
        display.value = "Error";
    }
}