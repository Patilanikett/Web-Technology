
function changeLight(color) {

    let red = document.getElementById("red");
    let yellow = document.getElementById("yellow");
    let green = document.getElementById("green");

    red.className = "light";
    yellow.className = "light";
    green.className = "light";

    if (color === "red") {
        red.classList.add("red-active");
        message.innerText = "STOP";
    }

    else if (color === "yellow") {
        yellow.classList.add("yellow-active");
        message.innerText = "WAIT";
    }

    else if (color === "green") {
        green.classList.add("green-active");
        message.innerText = "GO";
    }
}
