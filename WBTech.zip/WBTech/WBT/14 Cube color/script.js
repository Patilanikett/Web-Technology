function setColor() {

    // Get three numbers
    let n1 = document.getElementById("num1").value;
    let n2 = document.getElementById("num2").value;
    let n3 = document.getElementById("num3").value;

    // Get selected color
    let color = document.getElementById("color").value;

    let numbers = [n1, n2, n3];

    // Validate empty fields
    if (numbers.some(num => num === "")) {
        alert("Please enter all three numbers");
        return;
    }

    // Convert string values into numbers
    numbers = numbers.map(Number);

    // Validate range
    if (numbers.some(num => !Number.isInteger(num) || num < 1 || num > 9)) {
        alert("Please enter numbers between 1 and 9");
        return;
    }

    // Validate duplicate numbers
    if (new Set(numbers).size !== 3) {
        alert("Please enter three different numbers");
        return;
    }

    // Apply color to selected cells
    numbers.forEach(num => {

        let cell = document.getElementById("cell" + num);

        cell.style.backgroundColor = color;

    });

    document.getElementById("message").innerText =
        "Color applied successfully!";

}


// Reset grid
function resetGrid() {

    for (let i = 1; i <= 9; i++) {

        document.getElementById("cell" + i).style.backgroundColor = "lightgray";

    }

    document.getElementById("num1").value = "";
    document.getElementById("num2").value = "";
    document.getElementById("num3").value = "";

    document.getElementById("message").innerText = "";

}